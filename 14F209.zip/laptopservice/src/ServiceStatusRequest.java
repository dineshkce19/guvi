

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servicestatus")
public class ServiceStatusRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public ServiceStatusRequest() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try(PrintWriter out = response.getWriter()){
			try {
				response.setContentType("text/html");
				request.getRequestDispatcher("index.html").include(request, response);
				String phone = request.getParameter("phone");
				PreparedStatement st = Database.getstmt("select * from service_details where phone=?");
				st.setString(1, phone);
				ResultSet flag =st.executeQuery();
				if(flag.next()){
					out.println("<h3>Service yet to be completed!!! please visit after some time...</h3>");
				}else{
					PreparedStatement st1 = Database.getstmt("select * from completed_services where phone=?");
					st1.setString(1, phone);
					ResultSet ff = st1.executeQuery();
					if(ff.next()){
						out.println("<h3>service completed</h3>");
					}else{
						out.println("<h3>Service not found !!! please do register a new service</h3>");
					}
				}
				
			} catch ( Exception e) {
				// TODO Auto-generated catch block
				out.println(e);
			}
			
		}
	}

}
