


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Database {
	public static Connection getConn(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/laptop","root","");
			return con;
		}catch(Exception e){
			return null;
		}
	}
	public static PreparedStatement getstmt(String sql){
		try{
			return getConn().prepareStatement(sql);
		}catch(Exception e){
			return null;
		}
	}
}
