

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Modify
 */
@WebServlet("/modify")
public class Modify extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Modify() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try(PrintWriter out = response.getWriter()){
			try {
				response.setContentType("text/html");
				request.getRequestDispatcher("index.html").include(request, response);
				PreparedStatement st = Database.getstmt("update service_details set firstName=?,lastName=?,email=?,address=?,laptopModel=?,laptopId=?,serviceDescription=? where phone=?");
				st.setString(1, request.getParameter("firstName"));
				st.setString(2, request.getParameter("lastName"));
				st.setString(3, request.getParameter("email"));
				st.setString(4, request.getParameter("address"));
				st.setString(5, request.getParameter("laptopModel"));
				st.setString(6, request.getParameter("laptopId"));
				st.setString(7, request.getParameter("serviceDescription"));
				st.setString(8, request.getParameter("phone"));
				int flag = st.executeUpdate();
				if(flag==1){
					out.println("<h3>Your Service has been Updated...</h3><br><h5>Please do use your phone number for further details </h5><br>");
					out.println("<table class=\"table  table-hover table-responsive\">");
					out.println("<tr><td>First Name</td><td>"+ request.getParameter("firstName") +"</td></tr>");
					out.println("<tr><td>Last Name</td><td>"+ request.getParameter("lastName") +"</td></tr>");
					out.println("<tr><td>e-Mail</td><td>"+ request.getParameter("email") +"</td></tr>");
					out.println("<tr><td>Phone</td><td>"+  request.getParameter("phone")+"</td></tr>");
					out.println("<tr><td>Address</td><td>"+request.getParameter("address")+"</td></tr>");
					out.println("<tr><td>Laptop Model</td><td>"+request.getParameter("laptopModel")+"</td></tr>");
					out.println("<tr><td>Laptop ID</td><td>"+request.getParameter("laptopId")+"</td></tr>");
					out.println("<tr><td>Service Description</td><td>"+request.getParameter("serviceDescription")+"</td></tr>");
					out.println("</table>");
				}else{
					out.println("<h3>Service registration failed try again later</h3>");
				}
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				out.println(e);
			}
			
		}
	}

}
