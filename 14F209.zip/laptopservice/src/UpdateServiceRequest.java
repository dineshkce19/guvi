

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class UpdateServiceRequest
 */
@WebServlet("/updateservice")
public class UpdateServiceRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServiceRequest() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try(PrintWriter out = response.getWriter()){
			try {
				response.setContentType("text/html");
				request.getRequestDispatcher("index.html").include(request, response);
				String phone = request.getParameter("phone");
				PreparedStatement st = Database.getstmt("select * from service_details where phone=?");
				st.setString(1, phone);
				ResultSet rs  = st.executeQuery();
				if(rs.next()){
					out.println("<div class='container'><form class='well form-horizontal' action='modify' method='post'  id='contact_form'><fieldset>");
					
					out.println("<div class='form-group'>");
					out.println("<label class='col-md-4 control-label'>First Name</label>");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println("<span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>");
					out.println("<input  name='firstName' placeholder='First Name' class='form-control'  type='text' required value="+rs.getString(1)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println("<label class='col-md-4 control-label' >Last Name</label> ");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println("<span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>");
					out.println("<input name='lastName' placeholder='Last Name' class='form-control'  type='text' value="+rs.getString(2)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println("<label class='col-md-4 control-label'>E-Mail</label>  ");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println("<span class='input-group-addon'><i class='glyphicon glyphicon-envelope'></i></span>");
					out.println("<input name='email' placeholder='E-Mail Address' class='form-control'  type='text'  value="+rs.getString(3)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println(" <label class='col-md-4 control-label'>Phone #</label>  ");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println("<span class='input-group-addon'><i class='glyphicon glyphicon-earphone'></i></span>");
					out.println("<input name='phone' placeholder='9884332115' class='form-control' type='text' required value="+rs.getString(4)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println(" <label class='col-md-4 control-label'>Address</label>");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println("<span class='input-group-addon'><i class='glyphicon glyphicon-home'></i></span>");
					out.println(" <input name='address' placeholder='Address' class='form-control' type='text' required value="+rs.getString(5)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println("<label class='col-md-4 control-label'>Laptop Model</label> ");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println(" <span class='input-group-addon'><i class='glyphicon glyphicon-modal-window'></i></span>");
					out.println("<input name='laptopModel' placeholder='Laptop model' class='form-control' type='text' required value="+rs.getString(6)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println("<label class='col-md-4 control-label'>Laptop ID</label>  ");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println(" <span class='input-group-addon'><i class='glyphicon glyphicon-modal-window'></i></span>");
					out.println("<input name='laptopId' placeholder='Laptop ID' class='form-control' type='text' required value="+rs.getString(7)+">");
					out.println(" </div></div></div>");
					
					out.println("<div class='form-group'>");
					out.println(" <label class='col-md-4 control-label'>Service Description</label>");  
					out.println("<div class='col-md-4 inputGroupContainer'>");
					out.println("<div class='input-group'>");
					out.println("<span class='input-group-addon'><i class='glyphicon glyphicon-pencil'></i></span>");
					out.println("<textarea class='form-control' name='serviceDescription' placeholder='Laptop Service Description' required value="+rs.getString(8)+"></textarea>");
					out.println(" </div></div></div>");
					
					
					out.println("<button type='submit' class='btn btn-warning' >Confirm Service Request <span class='glyphicon glyphicon-send'></span></button>");
					
					out.println("</fieldset></form></div>");
				}else{
					out.println("<h3>Service not found !!! please do register a new service</h3>");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				out.println(e);
			}			
		}
	}

}
