create database laptop;

use laptop;

create table service_details(firstName varchar(256) not null,lastName varchar(256),email varchar(256),phone varchar(256) primary key,address varchar(256),laptopModel varchar(256),laptopId varchar(256),serviceDescription varchar(256) not null);	

desc service_details;

insert into service_details values('dinesh','raja','dinesh@gmail.com','9952776436','kce,coimbatore','hp','jh12-21n21','OS Boot problem');

insert into service_details values('abcd','efgh','asdf@gmail.com','12456789','ku,cbe','dell ','1223xas-sad1','display');
	
create table completed_services(firstName varchar(256) not null,lastName varchar(256),email varchar(256),phone varchar(256) primary key,address varchar(256),laptopModel varchar(256),laptopId varchar(256),serviceDescription varchar(256) not null);	
	